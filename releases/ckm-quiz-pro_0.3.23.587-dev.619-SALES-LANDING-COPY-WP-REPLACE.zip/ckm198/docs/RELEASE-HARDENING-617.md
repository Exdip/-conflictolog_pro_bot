# CKM Quiz Pro 0.3.23.585-dev.617-RELEASE-HARDENING

Продолжение текущего rc615-review дерева. Исходный архив .615 сохранён.
Версия .616 была промежуточным состоянием hardening; после полного зелёного
gate 278/278 версия повышена до .617. Production-сайт и live-сервисы не изменялись.

Все 11 замечаний review подтверждены и исправлены:

| № | Замечание и исправление | Регрессионная проверка |
|---|---|---|
| 1 | Нестандартная цена, запрос скидки, возврат оплаты и запрос человека распознаются до автономного результата. Outcome независимо соблюдает обязательный handoff. | sales-616-handoff-safety.php; sales-616-turn-budget-safety.php |
| 2 | Валидный model handoff сохраняется, получает причину policy и переводит сессию и Inbox в human. Отказ или END_NO_SALE не могут переопределить передачу. | sales-616-handoff-safety.php |
| 3 | Legacy OpenAI Live SIP явно отключён в webhook, incoming/outbound service и sideband registration. Старые сессии останавливаются реальным запросом hangup; ошибка сохраняет stop_pending и требует ручного завершения у провайдера. Worker закрывает socket при disabled/error. Modern Media Gateway использует общий серверный runtime, очередь человека и существующую команду PBX transfer. | sales-616-legacy-sip-safety.php; sales-616-legacy-worker-safety-test.cjs; sales-616-channel-handoff.php |
| 4 | Workspace closure захватывает sid; внешние разговоры получают уникальный conversation_id. | sales-616-workspace-storage.php |
| 5 | Подтверждение рекомендации связано с исходной ревизией и canonical patch fingerprint. Устаревшее подтверждение отклоняется до записи и внутри mutation. | sales-616-revision-safety.php; sales-616-confirmation-flow-test.mjs |
| 6 | Rollback разрешён только последнему актуальному изменению, проверяет ожидаемую ревизию повторно при mutation и записывает новую ревизию вместе с историей. ABA не возвращает доступность старого отката. | sales-616-revision-safety.php; sales-616-confirmation-flow-test.mjs |
| 7 | Полное правило длиннее 500 символов отклоняется целиком; настройки и история не меняются. Частичное сохранение исключено. | sales-616-revision-safety.php; sales-616-confirmation-flow-test.mjs; sales-616-workspace-storage.php |
| 8 | Impact учитывает только завершённые применимые AI-разговоры с доказанной общей ревизией и fingerprint конфигурации в журнале. Active, human_import, смешанные и старые журналы без provenance исключены. | sales-616-impact-quality.php |
| 9 | Quality использует автономный режим непосредственно события handoff. | sales-616-impact-quality.php |
| 10 | Bootstrap sales-576 подключает реальные новые зависимости Workspace; исходные assertions сохранены. | sales-576-real-dialog-import.php |
| 11 | Удалены только неиспользуемые assets/archive_26_09_19_22_08_57.zip и assets/standalone-game0.js; ссылки runtime на них отсутствуют. | sales-616-release-package-test.mjs |

В AGENTS.md добавлено правило: «обязательный handoff/stop-signal является hard
safety boundary и никогда не может быть переопределён автономным решением модели
или постобработкой».

Дополнительно исправлены реальные дефекты, выявленные полным suite и проверками:

- Reveal contract: слова о «проблеме» в полном описании ошибочно меняли тему
  бюджетного факта. Основная тема теперь берётся из partial rule. Склонение
  «дополнительной сделки» распознаётся, поэтому общий вопрос о потерях лидов
  не раскрывает экономику сделки. Исходные sales-482/483/486 assertions
  сохранены; sales-616-reveal-topic.php содержит семь проверок.
- Inbound phone lookup использовал создателя интеграции вместо assigned_user_id.
  Теперь script lookup и сохранённый владелец звонка согласованы; разные
  создатель и назначенный продавец проверены в channel-handoff suite.
- Завершённый или переданный телефонный звонок мог снова принять turn/speak.
  Эти обращения отклоняются. Ручной PBX transfer устанавливает необратимую
  handoff boundary до постановки команды: AI resume, won/end и публичное
  завершение запрещены. Обязательный transfer ставится один раз. Обычный
  ручной перехват сохраняет возможность явного возврата AI, когда перевода не было.
- Лимит 40 реплик блокировал обязательный handoff и очередь человека.
  Он сохранён для AI-ветки; safety boundary обрабатывается независимо от него.
- Конкурирующая запись metadata могла затереть новую ревизию после проверки.
  Script mutation использует WordPress compare-and-swap по предыдущему значению;
  регрессия проверяет сохранность результата конкурирующей записи.

Исторические тесты не удалялись и не исключались. Их фикстуры дополнены там,
где текущий runtime требует раскрытого состояния; source assertions читают
действительно подключённый versioned implementation. CRLF нормализуется только
на входе тестов. Устаревшие ожидания включённого legacy SIP заменены проверками
его явного отключения с сохранением auth/tenant/modern gateway проверок.
Дополнительно исправлены скобка и экранирование литерала в этих тестах.

Порог 75, пять критериев, evaluation-модули и исходный content pack сохранены.
Новые LLM-вызовы не добавлены. Встроенные обязательные стоп-сигналы сохраняют
приоритет после рекомендаций, пользовательских правил, rollback и handoff.

## Повторяемый полный gate

```sh
node tests/run-preinstall-gate.mjs --php /path/to/php83-or-wasm-cli.mjs --parser /path/to/php-parser --jobs 3 --output /path/outside-plugin
```

Suite содержит 266 исходных entrypoint-тестов и 12 новых: всего 278.
Gate всегда запускает все entrypoints, включая оставшиеся после раннего FAIL.
Новый orchestrator проверяет 15 сценариев реального POST handler, nonce,
prepare/confirm, revision/patch conflicts, redirect и атомарный отказ.
PHP parser проверяет всё дерево; TOKEN_PARSE выполняется реальным PHP 8.3;
node --check проверяет все JS/MJS/CJS. Tenant/owner isolation, lifecycle,
handoff safety, architecture guards и release-package audit включены в suite.
Существующий точный URL логотипа остаётся единственным разрешённым branding
asset в guards; бизнес-логика не зависит от production endpoint.

## Границы проверки

Проверки offline: реальный PHP 8.3.33 WebAssembly CLI и Node, реальные
production-сервисы, изолированные WordPress/storage/HTTP/transport фикстуры.
PHP runtime не является установленным live WordPress. Не выполнялись установка
на рабочий сайт, реальная WordPress UI/БД, PBX/SIP звонки, messenger webhooks,
Deepgram/Cartesia/Voice Gateway, внешняя LLM и live smoke-test.

Legacy SIP intentionally disabled. Завершение старого звонка у провайдера
нельзя считать выполненным при ошибке hangup: состояние stop_pending и
manual_termination_required сохраняются. Modern phone без transfer target
остаётся в человеческой очереди; подключение оператора проверяется отдельно live.
Журналы до введения configuration provenance не дают доказательной выборки impact.

После сборки ZIP извлекается в отдельный каталог; там выполняется тот же полный
gate. SHA-256 и размер относятся к проверенному ZIP, который больше не изменяется.
